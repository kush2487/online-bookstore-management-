<div id="footer-wrap">
	<p id="legal">(c) 2020 OurSite. Design by <a href="http://www.abc.com"> knowledge</a>.</p>
	</div>